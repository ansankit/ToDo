package com.todo.pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "my_user")
public class User {
	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
	   @Column
	   private Long user_id;
	   
	   @Column
	   private String username;
	   
	   @Column
	   private String password;
	
	public User() {
		
	}
	
	public User(long userId, String username, String password) {
		super();
		this.user_id=userId;
		this.password=password;
		this.username=username;
	}
	   public Long getUserId() {
		return user_id;
	}

	public void setUserId(Long userId) {
		this.user_id = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	  @Override
		public String toString() {
			return "User [userId=" + user_id + ", username=" + username + ", password=" + password + ", getUserId()="
					+ getUserId() + ", getUsername()=" + getUsername() + ", getPassword()=" + getPassword()
					+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
					+ "]";
		}
	    
}

