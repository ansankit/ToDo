package com.todo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.todo.pojo.ToDo;
import com.todo.pojo.User;

@Repository
public interface ToDoRepository extends JpaRepository<ToDo, Long> {
    List<ToDo> findByUser(User user);

    Optional<ToDo> findByIdAndUser(Long id, User user);

    void deleteByIdAndUser(Long id, User user);
}
