package com.todo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.todo.pojo.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	@Query(value = "SELECT user_id,username,password FROM my_user WHERE username = ?1 AND password = ?2", nativeQuery= true)
	Optional<User> findByUsernameAndPassword(String username,String password);
}
