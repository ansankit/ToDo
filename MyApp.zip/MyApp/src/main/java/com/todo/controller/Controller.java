package com.todo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todo.pojo.ToDo;
import com.todo.service.ToDoService;

@RestController
@RequestMapping("/api/todo")
public class Controller {
	@Autowired
	private ToDoService toDoService;
	
	
	@GetMapping("/{username}/{password}")
	public List<ToDo> getAllToDos(@PathVariable String username, @PathVariable String password) {
		System.out.println("getAllToDos");
		if (toDoService.verifyUser(username, password)) {
			return toDoService.getAllToDos(username, password);
		}
		return null;
	}

	@GetMapping("/{username}/{password}/{id}")
	public ToDo getToDoById(@PathVariable Long id, @PathVariable String username, @PathVariable String password) {
		if (toDoService.verifyUser(username, password)) {
			return toDoService.getToDoById(id, username, password);
		}
		return null;
	}

	@PostMapping("/{username}/{password}")
	public ToDo addToDo(@RequestBody ToDo toDo, @PathVariable String username, @PathVariable String password) {
		if (toDoService.verifyUser(username, password)) {
			return toDoService.addToDo(toDo, username, password);
		}
		return null;
	}

	@PutMapping("/{username}/{password}/{id}")
	public ToDo updateToDoById(@RequestBody ToDo updatedToDo, @PathVariable Long id, @PathVariable String username,
			@PathVariable String password) {
		if (toDoService.verifyUser(username, password)) {
			return toDoService.updateToDoById(id, updatedToDo, username, password);
		}
		return null;
	}

	@DeleteMapping("/{username}/{password}/{id}")
	public void deleteToDoById(@PathVariable Long id, @PathVariable String username, @PathVariable String password) {
		if (toDoService.verifyUser(username, password)) {
			toDoService.deleteToDoById(id, username, password);
		}
	}
}
