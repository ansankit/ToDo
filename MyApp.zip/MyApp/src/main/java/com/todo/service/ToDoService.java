package com.todo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.todo.pojo.ToDo;
import com.todo.pojo.User;
import com.todo.repository.ToDoRepository;
import com.todo.repository.UserRepository;

@Service
@Transactional
public class ToDoService {
	@Autowired
	private ToDoRepository toDoRepository;

	@Autowired
	private UserRepository userRepository;

	public boolean verifyUser(String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		return userOptional.isPresent();
	}

	public List<ToDo> getAllToDos(String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			return toDoRepository.findByUser(user);
		}
		return null;
	}

	public ToDo getToDoById(Long id, String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			Optional<ToDo> toDoOptional = toDoRepository.findByIdAndUser(id, user);
			return toDoOptional.orElse(null);
		}
		return null;
	}

	public void deleteToDoById(Long id, String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			toDoRepository.deleteByIdAndUser(id, user);
		}
	}

	public ToDo updateToDoById(Long id, ToDo updatedToDo, String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			Optional<ToDo> existingToDoOptional = toDoRepository.findByIdAndUser(id, user);
			if (existingToDoOptional.isPresent()) {
				ToDo existingToDo = existingToDoOptional.get();
				existingToDo.setDescription(updatedToDo.getDescription());
				existingToDo.setCompleted(updatedToDo.isCompleted());
				return toDoRepository.save(existingToDo);
			}
		}
		return null;
	}

	public ToDo addToDo(ToDo toDo, String username, String password) {
		Optional<User> userOptional = userRepository.findByUsernameAndPassword(username, password);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			toDo.setUser(user);
			return toDoRepository.save(toDo);
		}
		return null;
	}
}
